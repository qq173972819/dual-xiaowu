"""Reusable image fitting and e-ink quantization helpers."""
from __future__ import annotations

from PIL import Image, ImageEnhance, ImageFilter, ImageOps

from . import native_dither


def _aligned_offset(container: int, content: int, align: str) -> int:
    if align in ("left", "top", "start"):
        return 0
    if align in ("right", "bottom", "end"):
        return container - content
    return (container - content) // 2


def fit_image_to_box(
    src: Image.Image,
    width: int,
    height: int,
    *,
    fit: str = "fill",
    align_x: str = "center",
    align_y: str = "center",
) -> Image.Image:
    """Fit an image into an RGB box using JSON image-block semantics."""
    src_rgba = ImageOps.exif_transpose(src).convert("RGBA")
    fit_mode = str(fit or "fill").lower()
    if fit_mode in ("fill", "stretch"):
        base = Image.new("RGBA", (width, height), (255, 255, 255, 255))
        base.alpha_composite(src_rgba.resize((width, height), Image.LANCZOS))
        return base.convert("RGB")

    src_w = max(1, src_rgba.size[0])
    src_h = max(1, src_rgba.size[1])
    scale_x = width / src_w
    scale_y = height / src_h

    if fit_mode == "contain_blur":
        # 前景：等比缩放到完整可见（contain 语义，绝不拉伸/裁切主体）
        fg_scale = min(scale_x, scale_y)
        fg_w = max(1, int(round(src_w * fg_scale)))
        fg_h = max(1, int(round(src_h * fg_scale)))
        fg = src_rgba.resize((fg_w, fg_h), Image.LANCZOS)

        # 背景：同一张图 cover 填满 + 强高斯模糊 + 压暗，避免留白同时突出前景
        bg_scale = max(scale_x, scale_y)
        bg_w = max(1, int(round(src_w * bg_scale)))
        bg_h = max(1, int(round(src_h * bg_scale)))
        bg = src_rgba.resize((bg_w, bg_h), Image.LANCZOS)
        blur_radius = max(8, int(round(min(width, height) * 0.07)))
        bg = bg.filter(ImageFilter.GaussianBlur(radius=blur_radius))
        base = Image.new("RGBA", (width, height), (255, 255, 255, 255))
        base.alpha_composite(
            bg,
            (_aligned_offset(width, bg_w, align_x), _aligned_offset(height, bg_h, align_y)),
        )
        bg_rgb = ImageEnhance.Brightness(base.convert("RGB")).enhance(0.80)
        bg_rgb = ImageEnhance.Color(bg_rgb).enhance(0.85)
        base = bg_rgb.convert("RGBA")

        base.alpha_composite(
            fg,
            (_aligned_offset(width, fg_w, align_x), _aligned_offset(height, fg_h, align_y)),
        )
        return base.convert("RGB")

    scale = min(scale_x, scale_y) if fit_mode == "contain" else max(scale_x, scale_y)
    resized_w = max(1, int(round(src_w * scale)))
    resized_h = max(1, int(round(src_h * scale)))
    resized = src_rgba.resize((resized_w, resized_h), Image.LANCZOS)
    base = Image.new("RGBA", (width, height), (255, 255, 255, 255))
    paste_x = _aligned_offset(width, resized_w, align_x)
    paste_y = _aligned_offset(height, resized_h, align_y)
    base.alpha_composite(resized, (paste_x, paste_y))
    return base.convert("RGB")


def _gamma_lut(gamma: float) -> list[int]:
    inv = 1.0 / gamma
    return [min(255, int(255.0 * ((i / 255.0) ** inv) + 0.5)) for i in range(256)]


# 墨水屏只有黑/白(/黄/红)极少数颜色，照片中间调在量化后会大面积坍缩成白色，
# 因此必须在上游主动加深中间调、提高色彩浓度。
_PHOTO_GAMMA_LUT = _gamma_lut(0.86)


def enhance_photo_for_eink(rgb: Image.Image) -> Image.Image:
    """Photo preparation tuned for the limited black/white(/yellow/red) e-ink palette.

    - autocontrast：拉开色阶
    - 饱和度：让暖色（肤色、黄色衣物等）能量化到黄/红，而不是全部发白
    - gamma<1：压深中间调，避免量化后整体偏浅
    - 对比度 + 锐化 + 反锐化掩模：提升墨水屏上的通透感与边缘清晰度
    """
    img = ImageOps.autocontrast(rgb.convert("RGB"), cutoff=0.5)
    img = ImageEnhance.Color(img).enhance(1.45)
    img = img.point(_PHOTO_GAMMA_LUT * 3)
    img = ImageEnhance.Contrast(img).enhance(1.22)
    img = ImageEnhance.Sharpness(img).enhance(1.35)
    return img.filter(ImageFilter.UnsharpMask(radius=0.9, percent=100, threshold=2))


def quantize_image_for_eink(
    rgb: Image.Image,
    *,
    colors: int,
    photo_enhance: bool = False,
) -> Image.Image:
    """Quantize RGB image data for 2-, 3-, or 4-color e-ink output with Atkinson dithering."""
    prepared = enhance_photo_for_eink(rgb) if photo_enhance else rgb.convert("RGB")

    if colors < 3:
        gray = ImageOps.autocontrast(prepared.convert("L"), cutoff=0.5)
        return native_dither.atkinson_bw(gray)

    return native_dither.atkinson_palette(prepared, 3 if colors == 3 else 4)


def convert_image_block(
    src: Image.Image,
    width: int,
    height: int,
    colors: int,
    *,
    fit: str = "fill",
    align_x: str = "center",
    align_y: str = "center",
    photo_enhance: bool = False,
) -> Image.Image:
    """Fit and quantize an image for a JSON image block."""
    fitted = fit_image_to_box(src, width, height, fit=fit, align_x=align_x, align_y=align_y)
    return quantize_image_for_eink(
        fitted,
        colors=colors,
        photo_enhance=photo_enhance,
    )
